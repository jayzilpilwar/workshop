def hello2(request):
    return "Hello, two!"


