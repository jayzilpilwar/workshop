def hello2(request):
    return "hello Jay"