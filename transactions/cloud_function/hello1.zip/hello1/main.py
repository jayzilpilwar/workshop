def hello1(request):
    return "Hello Jay!"