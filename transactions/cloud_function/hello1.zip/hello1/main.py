def hello1(request):
    return "hello Jay"